using System;
using ngf;
using ngf.Input;

namespace demo
{
	class Game
	{
		private static ushort shaderId = 0;
		
		public static void Initialize()
		{
			shaderId = Gfx.LoadShader("Sprite");
			Gfx.InitUniform("s_texColor", UniformType.Sampler);
			Gfx.InitUniform("atlasInfo", UniformType.Vec4, 2);
		}

		public static void Update()
		{
			return;
		}
		
		public static void Render()
		{
			return;
		}
		
		public static void Unload()
		{
			Gfx.ReleaseShader(shaderId);
		}
	}
}