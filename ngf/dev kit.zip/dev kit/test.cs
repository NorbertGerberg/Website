using System;
using ngf;
using ngf.Input;

namespace test
{
	class Game
	{
		private static ushort shaderId = 0;
		private static ushort texId = 0;
		private static ushort layerId = 0;
		private static ushort viewportId = 0;
		
		private static Viewport vp;
		
		private static float rotation = 0.0f;
		
		private static ushort atlasId;
		
		private static ushort soundId;
		
		public static void Initialize()
		{
			Core.SetWindowSize(new vec2i(1280, 720));
			Core.SetVsync(true);
			Core.SetMsaa(16);
			Core.SetWindowTitle("Monkey Game :)");
			
			shaderId = Gfx.LoadShader("Sprite");
			Gfx.InitUniform("s_texColor", UniformType.Sampler);
			Gfx.InitUniform("atlasInfo", UniformType.Vec4, 2);
			
			texId = Gfx.LoadTexture("g.png", false, true);

			vp.position = new vec2(-50.0f, 0.0f);
			vp.size = new vec2(1280.0f, 720.0f);
			viewportId = Gfx.CreateViewport(vp);
			
			Layer layer;
			layer.id = 0;
			layer.resolution = new vec2i(1280, 720);
			layer.aspectRatio = new vec2i(1280, 720);
			layer.position = new vec2i(0);
			layer.topMost = true;
			layer.clearColor = 0xFFFFFFFF;
			layer.transparent = false;
			layer.updateSize = true;
			layer.viewport = viewportId;
			layerId = Gfx.CreateLayer(layer);

			TextureAtlas atlas;
			atlas.size = new vec2(192.0f);
			atlas.subImageSize = new vec2(64.0f);
			atlas.texture = texId;
			atlasId = Gfx.CreateTextureAtlas(atlas);
			
			soundId = Audio.LoadSound("f.wav");
			//Audio.PlaySound(soundId, 1.0f);
			
			Core.SetCursorImage("Crosshair");
			//Mouse.SetCursorMode((int)CursorMode.CURSOR_HIDDEN);
			Mouse.CheckRawMouseMotionSupport();
			
			//Audio.Update3DAudio(true);
			//Audio.PlaySound3D(soundId, 1.0f, new vec3(-50.0f, 0.0f, 0.0f));
			//Audio.Set3dSourcePosition(soundId, new vec3(-50.0f, 0.0f, 0.0f));
			//Audio.Set3dListenerPosition(new vec3(-5.0f, 0.0f, 0.0f));
			
			Core.SetWindowIcon("n.png", 16.0f, 16.0f);
		}
		private static bool isPressed = false;
		public static void Update()
		{
			//vp.position.x -= 5.0f * (float)Core.DeltaTime();
			//vp.position.y -= 1.5f * (float)Core.DeltaTime();
			//Gfx.UpdateViewport(viewportId, vp);
			
			rotation += 30.0f * (float)Core.DeltaTime();
			if(rotation >= 360)
			{
				rotation = 0.0f;
				Audio.PauseSound(soundId, true);
			}
			
			if(Keyboard.GetKeyPressed((int)KeyboardKey.KEY_F) && !isPressed)
			{
				Core.SwitchFullscreen(false);
				isPressed = true;
			}
			
			if(Keyboard.GetKeyReleased((int)KeyboardKey.KEY_F) && isPressed)
				isPressed = false;
			
			if(Gamepad.IsConnected(0))
			{	
				if(Gamepad.GetThumbRX() >= 6000)
					Gamepad.Vibration(0, 30000, 20000);
				else
					Gamepad.Vibration(0, 0, 0);
			}
		}
		
		public static void Render()
		{
			Gfx.SetActiveLayer(layerId);
			Gfx.SetActiveShader(shaderId);
			Gfx.DrawSprite(new vec2(0.0f), new vec2(64.0f), rotation, texId, new vec2(0.5f));

			Gfx.DrawSpriteAtlas(new vec2(50.0f, 10.0f), new vec2(64.0f), -rotation, atlasId, new vec2(1.0f),
				new vec2(0.5f));
		}
		
		public static void Unload()
		{
			Audio.ReleaseSound(soundId);
			Gfx.ReleaseTexture(texId);
			Gfx.DestroyLayer(layerId);
			Gfx.DestroyViewport(viewportId);
			Gfx.ReleaseShader(shaderId);
		}
	}
}